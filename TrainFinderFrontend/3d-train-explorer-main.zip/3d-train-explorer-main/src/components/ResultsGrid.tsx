import TrainCard3D from './TrainCard3D';
import { Train } from 'lucide-react';

interface Station {
  stationCode: string;
  stationName: string;
  arrivalTime: string;
  departureTime: string;
  haltDuration: string;
  distance: number;
  dayNumber: number;
}

interface TrainData {
  trainNumber: string;
  trainName: string;
  runningDays: string[];
  sourceStation: Station;
  destinationStation: Station;
  stations: Station[];
}

interface ResultsGridProps {
  trains: TrainData[];
  source: string;
  destination: string;
}

const ResultsGrid = ({ trains, source, destination }: ResultsGridProps) => {
  if (trains.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-secondary/50 flex items-center justify-center">
          <Train className="w-10 h-10 text-muted-foreground" />
        </div>
        <h3 className="font-display text-xl font-semibold text-foreground mb-2">
          No Trains Found
        </h3>
        <p className="text-muted-foreground max-w-md mx-auto">
          We couldn't find any trains from <span className="text-primary font-medium">{source}</span> to{' '}
          <span className="text-accent font-medium">{destination}</span>. Try different station codes.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Results Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="font-display text-2xl font-bold text-foreground">
            Available Trains
          </h2>
          <p className="text-muted-foreground mt-1">
            <span className="text-primary">{source}</span>
            <span className="mx-2">→</span>
            <span className="text-accent">{destination}</span>
            <span className="mx-2">•</span>
            <span>{trains.length} train{trains.length !== 1 ? 's' : ''} found</span>
          </p>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {trains.map((train, index) => (
          <TrainCard3D key={train.trainNumber} train={train} index={index} />
        ))}
      </div>
    </div>
  );
};

export default ResultsGrid;
