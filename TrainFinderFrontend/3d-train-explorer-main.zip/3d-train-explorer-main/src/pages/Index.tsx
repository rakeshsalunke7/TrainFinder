import { useState } from 'react';
import HeroSection from '@/components/HeroSection';
import SearchForm from '@/components/SearchForm';
import ResultsGrid from '@/components/ResultsGrid';
import Loader3D from '@/components/Loader3D';
import { AlertCircle } from 'lucide-react';

interface Station {
  stationCode: string;
  stationName: string;
  arrivalTime: string;
  departureTime: string;
  haltDuration: string;
  distance: number;
  dayNumber: number;
}

interface TrainData {
  trainNumber: string;
  trainName: string;
  runningDays: string[];
  sourceStation: Station;
  destinationStation: Station;
  stations: Station[];
}

const Index = () => {
  const [trains, setTrains] = useState<TrainData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchParams, setSearchParams] = useState({ source: '', destination: '' });

  const handleSearch = async (source: string, destination: string) => {
    setIsLoading(true);
    setError(null);
    setHasSearched(true);
    setSearchParams({ source, destination });

    try {
      const response = await fetch(
        `http://localhost:8080/search/by-code?sourceCode=${encodeURIComponent(source)}&destinationCode=${encodeURIComponent(destination)}`
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch trains: ${response.status}`);
      }

      const data = await response.json();
      setTrains(Array.isArray(data) ? data : [data]);
    } catch (err) {
      console.error('Search error:', err);
      setError(
        err instanceof Error 
          ? err.message 
          : 'Failed to fetch train data. Please ensure the backend server is running.'
      );
      setTrains([]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Search Section */}
      <section className="relative z-10 -mt-8 px-4 pb-8">
        <SearchForm onSearch={handleSearch} isLoading={isLoading} />
      </section>

      {/* Results Section */}
      <section className="px-4 py-12">
        {isLoading ? (
          <Loader3D />
        ) : error ? (
          <div className="max-w-2xl mx-auto">
            <div className="glass-card rounded-2xl p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-destructive/20 flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-destructive" />
              </div>
              <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                Connection Error
              </h3>
              <p className="text-muted-foreground mb-4">{error}</p>
              <p className="text-sm text-muted-foreground">
                Make sure the Spring Boot backend is running at{' '}
                <code className="px-2 py-1 bg-secondary rounded text-primary">http://localhost:8080</code>
              </p>
            </div>
          </div>
        ) : hasSearched ? (
          <ResultsGrid 
            trains={trains} 
            source={searchParams.source} 
            destination={searchParams.destination} 
          />
        ) : null}
      </section>

      {/* Footer */}
      <footer className="border-t border-border/30 py-8 px-4 mt-auto">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-muted-foreground">
            Built with React, Tailwind CSS, and Spring Boot
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
